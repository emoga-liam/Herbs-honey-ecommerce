"use client"

import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
  type ReactNode,
} from "react"

export type UnitType = "sachet" | "box"

export type CartItem = {
  productId: number
  slug: string
  name: string
  image: string | null
  unitType: UnitType
  unitPrice: number
  quantity: number
  maxStock: number
}

type CartContextValue = {
  items: CartItem[]
  count: number
  subtotal: number
  addItem: (item: Omit<CartItem, "quantity">, quantity?: number) => void
  updateQuantity: (productId: number, unitType: UnitType, quantity: number) => void
  removeItem: (productId: number, unitType: UnitType) => void
  clear: () => void
}

const CartContext = createContext<CartContextValue | null>(null)

const STORAGE_KEY = "naija-mart-cart"

function key(productId: number, unitType: UnitType) {
  return `${productId}:${unitType}`
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([])
  const [hydrated, setHydrated] = useState(false)

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY)
      if (raw) setItems(JSON.parse(raw))
    } catch {
      // ignore
    }
    setHydrated(true)
  }, [])

  useEffect(() => {
    if (!hydrated) return
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items))
  }, [items, hydrated])

  const addItem = useCallback(
    (item: Omit<CartItem, "quantity">, quantity = 1) => {
      setItems((prev) => {
        const existing = prev.find(
          (i) => key(i.productId, i.unitType) === key(item.productId, item.unitType),
        )
        if (existing) {
          return prev.map((i) =>
            key(i.productId, i.unitType) === key(item.productId, item.unitType)
              ? { ...i, quantity: Math.min(i.quantity + quantity, item.maxStock) }
              : i,
          )
        }
        return [...prev, { ...item, quantity: Math.min(quantity, item.maxStock) }]
      })
    },
    [],
  )

  const updateQuantity = useCallback(
    (productId: number, unitType: UnitType, quantity: number) => {
      setItems((prev) =>
        prev
          .map((i) =>
            key(i.productId, i.unitType) === key(productId, unitType)
              ? { ...i, quantity: Math.max(0, Math.min(quantity, i.maxStock)) }
              : i,
          )
          .filter((i) => i.quantity > 0),
      )
    },
    [],
  )

  const removeItem = useCallback((productId: number, unitType: UnitType) => {
    setItems((prev) =>
      prev.filter((i) => key(i.productId, i.unitType) !== key(productId, unitType)),
    )
  }, [])

  const clear = useCallback(() => setItems([]), [])

  const count = items.reduce((sum, i) => sum + i.quantity, 0)
  const subtotal = items.reduce((sum, i) => sum + i.quantity * i.unitPrice, 0)

  return (
    <CartContext.Provider
      value={{ items, count, subtotal, addItem, updateQuantity, removeItem, clear }}
    >
      {children}
    </CartContext.Provider>
  )
}

export function useCart() {
  const ctx = useContext(CartContext)
  if (!ctx) throw new Error("useCart must be used within CartProvider")
  return ctx
}
