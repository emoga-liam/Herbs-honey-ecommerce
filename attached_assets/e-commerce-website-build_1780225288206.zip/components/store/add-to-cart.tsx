"use client"

import { useState } from "react"
import { Minus, Plus, ShoppingCart } from "lucide-react"
import { toast } from "sonner"
import type { Product } from "@/lib/db/schema"
import { useCart, type UnitType } from "@/lib/cart"
import { formatNaira } from "@/lib/format"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

export function AddToCart({ product }: { product: Product }) {
  const { addItem } = useCart()
  const [unitType, setUnitType] = useState<UnitType>("sachet")
  const [quantity, setQuantity] = useState(1)

  const options: { type: UnitType; label: string; price: number; stock: number }[] = [
    {
      type: "sachet",
      label: "Single sachet",
      price: product.sachetPrice,
      stock: product.sachetStock,
    },
    {
      type: "box",
      label: `Full box (${product.sachetsPerBox} sachets)`,
      price: product.boxPrice,
      stock: product.boxStock,
    },
  ]

  const selected = options.find((o) => o.type === unitType)!
  const maxStock = selected.stock

  function handleAdd() {
    if (maxStock <= 0) return
    addItem(
      {
        productId: product.id,
        slug: product.slug,
        name: product.name,
        image: product.image,
        unitType,
        unitPrice: selected.price,
        maxStock,
      },
      quantity,
    )
    toast.success(`Added ${quantity} ${unitType}(s) of ${product.name} to cart`)
  }

  return (
    <div className="flex flex-col gap-5">
      <div className="flex flex-col gap-2">
        <span className="text-sm font-medium text-foreground">Choose option</span>
        <div className="grid grid-cols-2 gap-3">
          {options.map((o) => {
            const active = o.type === unitType
            const disabled = o.stock <= 0
            return (
              <button
                key={o.type}
                type="button"
                disabled={disabled}
                onClick={() => {
                  setUnitType(o.type)
                  setQuantity(1)
                }}
                className={cn(
                  "flex flex-col items-start gap-1 rounded-lg border p-3 text-left transition-colors",
                  active
                    ? "border-primary bg-primary/5"
                    : "border-border hover:border-primary/50",
                  disabled && "cursor-not-allowed opacity-50",
                )}
              >
                <span className="text-sm font-medium text-foreground">
                  {o.label}
                </span>
                <span className="text-base font-bold text-primary">
                  {formatNaira(o.price)}
                </span>
                <span className="text-xs text-muted-foreground">
                  {o.stock > 0 ? `${o.stock} in stock` : "Out of stock"}
                </span>
              </button>
            )
          })}
        </div>
      </div>

      <div className="flex items-center gap-4">
        <div className="flex items-center rounded-lg border border-border">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setQuantity((q) => Math.max(1, q - 1))}
            disabled={quantity <= 1}
            aria-label="Decrease quantity"
          >
            <Minus className="h-4 w-4" />
          </Button>
          <span className="w-10 text-center text-sm font-medium tabular-nums">
            {quantity}
          </span>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setQuantity((q) => Math.min(maxStock, q + 1))}
            disabled={quantity >= maxStock}
            aria-label="Increase quantity"
          >
            <Plus className="h-4 w-4" />
          </Button>
        </div>
        <span className="text-sm text-muted-foreground">
          Subtotal{" "}
          <span className="font-semibold text-foreground">
            {formatNaira(selected.price * quantity)}
          </span>
        </span>
      </div>

      <Button size="lg" onClick={handleAdd} disabled={maxStock <= 0}>
        <ShoppingCart className="h-4 w-4" />
        {maxStock <= 0 ? "Out of stock" : "Add to cart"}
      </Button>
    </div>
  )
}
