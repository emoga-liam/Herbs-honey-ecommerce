import Link from "next/link"
import Image from "next/image"
import type { Product } from "@/lib/db/schema"
import { formatNaira } from "@/lib/format"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export function ProductCard({ product }: { product: Product }) {
  const outOfStock = product.sachetStock <= 0 && product.boxStock <= 0

  return (
    <Link href={`/product/${product.slug}`} className="group">
      <Card className="h-full overflow-hidden p-0 transition-shadow hover:shadow-md">
        <div className="relative aspect-square overflow-hidden bg-secondary/40">
          <Image
            src={product.image ?? "/placeholder.svg"}
            alt={product.name}
            fill
            sizes="(max-width: 768px) 50vw, 25vw"
            className="object-cover transition-transform duration-300 group-hover:scale-105"
          />
          <Badge className="absolute left-3 top-3 bg-accent text-accent-foreground">
            {product.category}
          </Badge>
          {outOfStock && (
            <div className="absolute inset-0 flex items-center justify-center bg-background/70">
              <span className="text-sm font-semibold text-foreground">
                Out of stock
              </span>
            </div>
          )}
        </div>
        <div className="flex flex-col gap-1 p-4">
          <h3 className="font-semibold leading-tight text-foreground text-balance">
            {product.name}
          </h3>
          <p className="text-xs text-muted-foreground">
            {product.sachetsPerBox} sachets per box
          </p>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-sm text-muted-foreground">From</span>
            <span className="text-lg font-bold text-primary">
              {formatNaira(product.sachetPrice)}
            </span>
          </div>
        </div>
      </Card>
    </Link>
  )
}
