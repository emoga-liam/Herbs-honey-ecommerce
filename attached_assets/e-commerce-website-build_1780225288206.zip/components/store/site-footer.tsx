import Link from "next/link"

export function SiteFooter() {
  return (
    <footer className="mt-16 border-t border-border bg-secondary/40">
      <div className="mx-auto flex max-w-6xl flex-col gap-4 px-4 py-10 text-sm text-muted-foreground md:flex-row md:items-center md:justify-between">
        <div>
          <p className="font-semibold text-foreground">NaijaMart</p>
          <p className="mt-1 max-w-sm text-pretty">
            Everyday household essentials in sachets or full boxes, delivered
            across Nigeria.
          </p>
        </div>
        <div className="flex gap-6">
          <Link href="/shop" className="hover:text-foreground">
            Shop
          </Link>
          <Link href="/cart" className="hover:text-foreground">
            Cart
          </Link>
          <Link href="/admin" className="hover:text-foreground">
            Admin
          </Link>
        </div>
      </div>
    </footer>
  )
}
