"use client"

import { useMemo, useState } from "react"
import type { Product } from "@/lib/db/schema"
import { ProductCard } from "@/components/store/product-card"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

export function ShopGrid({ products }: { products: Product[] }) {
  const categories = useMemo(() => {
    const set = new Set(products.map((p) => p.category))
    return ["All", ...Array.from(set).sort()]
  }, [products])

  const [active, setActive] = useState("All")

  const filtered =
    active === "All"
      ? products
      : products.filter((p) => p.category === active)

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap gap-2">
        {categories.map((cat) => (
          <Button
            key={cat}
            variant={active === cat ? "default" : "outline"}
            size="sm"
            onClick={() => setActive(cat)}
            className={cn("rounded-full")}
          >
            {cat}
          </Button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <p className="py-16 text-center text-muted-foreground">
          No products in this category yet.
        </p>
      ) : (
        <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
          {filtered.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  )
}
