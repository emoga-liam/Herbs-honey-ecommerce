import { getActiveProducts } from "@/app/actions/store"
import { SiteHeader } from "@/components/store/site-header"
import { SiteFooter } from "@/components/store/site-footer"
import { ShopGrid } from "@/components/store/shop-grid"

export const metadata = {
  title: "Shop — NaijaMart",
}

export default async function ShopPage() {
  const products = await getActiveProducts()

  return (
    <div className="flex min-h-svh flex-col">
      <SiteHeader />
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-10">
        <div className="mb-8">
          <h1 className="text-3xl font-bold tracking-tight text-foreground">
            Shop all products
          </h1>
          <p className="mt-1 text-muted-foreground">
            {products.length} products available in sachets and boxes.
          </p>
        </div>
        <ShopGrid products={products} />
      </main>
      <SiteFooter />
    </div>
  )
}
