import Link from "next/link"
import { Package, Truck, Wallet } from "lucide-react"
import { getActiveProducts } from "@/app/actions/store"
import { SiteHeader } from "@/components/store/site-header"
import { SiteFooter } from "@/components/store/site-footer"
import { ProductCard } from "@/components/store/product-card"
import { Button } from "@/components/ui/button"

export default async function HomePage() {
  const products = await getActiveProducts()
  const featured = products.slice(0, 8)

  return (
    <div className="flex min-h-svh flex-col">
      <SiteHeader />

      <main className="flex-1">
        <section className="border-b border-border bg-secondary/40">
          <div className="mx-auto grid max-w-6xl gap-8 px-4 py-14 md:grid-cols-2 md:items-center md:py-20">
            <div className="flex flex-col gap-5">
              <span className="w-fit rounded-full bg-primary/10 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-primary">
                Buy small, buy big
              </span>
              <h1 className="text-balance text-4xl font-bold leading-tight tracking-tight text-foreground md:text-5xl">
                Everyday essentials in sachets or full boxes
              </h1>
              <p className="max-w-md text-pretty leading-relaxed text-muted-foreground">
                From detergents to seasoning and drinks, shop the household
                staples you love at retail or wholesale prices, delivered right
                to your door across Nigeria.
              </p>
              <div className="flex flex-wrap gap-3">
                <Button asChild size="lg">
                  <Link href="/shop">Start shopping</Link>
                </Button>
                <Button asChild variant="outline" size="lg">
                  <Link href="#featured">Browse essentials</Link>
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3 md:grid-cols-1 lg:grid-cols-3">
              <Feature
                icon={<Package className="h-5 w-5" />}
                title="Sachets & boxes"
                text="Pick a single sachet or save more with a full box."
              />
              <Feature
                icon={<Wallet className="h-5 w-5" />}
                title="Fair prices"
                text="Retail and wholesale pricing on every product."
              />
              <Feature
                icon={<Truck className="h-5 w-5" />}
                title="Fast delivery"
                text="Quick dispatch to your doorstep nationwide."
              />
            </div>
          </div>
        </section>

        <section id="featured" className="mx-auto max-w-6xl px-4 py-12">
          <div className="mb-6 flex items-end justify-between">
            <div>
              <h2 className="text-2xl font-bold tracking-tight text-foreground">
                Popular essentials
              </h2>
              <p className="text-sm text-muted-foreground">
                Stock up on what your home needs every day.
              </p>
            </div>
            <Button asChild variant="ghost" className="hidden sm:inline-flex">
              <Link href="/shop">View all</Link>
            </Button>
          </div>

          <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
            {featured.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </section>
      </main>

      <SiteFooter />
    </div>
  )
}

function Feature({
  icon,
  title,
  text,
}: {
  icon: React.ReactNode
  title: string
  text: string
}) {
  return (
    <div className="flex flex-col gap-2 rounded-xl border border-border bg-card p-4">
      <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 text-primary">
        {icon}
      </span>
      <p className="font-semibold text-foreground">{title}</p>
      <p className="text-sm leading-relaxed text-muted-foreground">{text}</p>
    </div>
  )
}
