import Image from "next/image"
import Link from "next/link"
import { notFound } from "next/navigation"
import { ChevronLeft } from "lucide-react"
import { getProductBySlug } from "@/app/actions/store"
import { SiteHeader } from "@/components/store/site-header"
import { SiteFooter } from "@/components/store/site-footer"
import { AddToCart } from "@/components/store/add-to-cart"
import { Badge } from "@/components/ui/badge"

export default async function ProductPage({
  params,
}: {
  params: Promise<{ slug: string }>
}) {
  const { slug } = await params
  const product = await getProductBySlug(slug)

  if (!product || !product.active) notFound()

  return (
    <div className="flex min-h-svh flex-col">
      <SiteHeader />
      <main className="mx-auto w-full max-w-5xl flex-1 px-4 py-8">
        <Link
          href="/shop"
          className="mb-6 inline-flex items-center gap-1 text-sm text-muted-foreground transition-colors hover:text-foreground"
        >
          <ChevronLeft className="h-4 w-4" />
          Back to shop
        </Link>

        <div className="grid gap-8 md:grid-cols-2">
          <div className="relative aspect-square overflow-hidden rounded-xl border border-border bg-secondary/40">
            <Image
              src={product.image ?? "/placeholder.svg"}
              alt={product.name}
              fill
              sizes="(max-width: 768px) 100vw, 50vw"
              className="object-cover"
              priority
            />
          </div>

          <div className="flex flex-col gap-4">
            <div className="flex flex-col gap-2">
              <Badge className="w-fit bg-accent text-accent-foreground">
                {product.category}
              </Badge>
              <h1 className="text-3xl font-bold tracking-tight text-foreground text-balance">
                {product.name}
              </h1>
              <p className="leading-relaxed text-muted-foreground text-pretty">
                {product.description}
              </p>
            </div>

            <AddToCart product={product} />
          </div>
        </div>
      </main>
      <SiteFooter />
    </div>
  )
}
