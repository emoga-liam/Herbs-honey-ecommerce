"use server"

import { db } from "@/lib/db"
import { products, orders, orderItems } from "@/lib/db/schema"
import { and, asc, eq, gt } from "drizzle-orm"

export type CartLine = {
  productId: number
  unitType: "sachet" | "box"
  quantity: number
}

export async function getActiveProducts() {
  return db
    .select()
    .from(products)
    .where(eq(products.active, true))
    .orderBy(asc(products.name))
}

export async function getProductBySlug(slug: string) {
  const rows = await db
    .select()
    .from(products)
    .where(eq(products.slug, slug))
    .limit(1)
  return rows[0] ?? null
}

export async function getProductsByIds(ids: number[]) {
  if (ids.length === 0) return []
  const all = await db.select().from(products).where(eq(products.active, true))
  return all.filter((p) => ids.includes(p.id))
}

type CheckoutInput = {
  customerName: string
  customerPhone: string
  customerAddress: string
  note?: string
  lines: CartLine[]
}

export async function createOrder(input: CheckoutInput) {
  const { customerName, customerPhone, customerAddress, note, lines } = input

  if (!customerName.trim() || !customerPhone.trim() || !customerAddress.trim()) {
    return { ok: false as const, error: "Please fill in all required fields." }
  }
  if (lines.length === 0) {
    return { ok: false as const, error: "Your cart is empty." }
  }

  const ids = Array.from(new Set(lines.map((l) => l.productId)))
  const found = await db
    .select()
    .from(products)
    .where(eq(products.active, true))
  const byId = new Map(found.filter((p) => ids.includes(p.id)).map((p) => [p.id, p]))

  // Validate stock and compute total.
  let total = 0
  const resolved: {
    productId: number
    productName: string
    unitType: "sachet" | "box"
    quantity: number
    unitPrice: number
  }[] = []

  for (const line of lines) {
    const product = byId.get(line.productId)
    if (!product) {
      return { ok: false as const, error: "A product in your cart is no longer available." }
    }
    const available =
      line.unitType === "box" ? product.boxStock : product.sachetStock
    if (line.quantity > available) {
      return {
        ok: false as const,
        error: `Only ${available} ${line.unitType}(s) of ${product.name} left in stock.`,
      }
    }
    const unitPrice =
      line.unitType === "box" ? product.boxPrice : product.sachetPrice
    total += unitPrice * line.quantity
    resolved.push({
      productId: product.id,
      productName: product.name,
      unitType: line.unitType,
      quantity: line.quantity,
      unitPrice,
    })
  }

  const [order] = await db
    .insert(orders)
    .values({
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim(),
      customerAddress: customerAddress.trim(),
      note: note?.trim() || null,
      total,
      status: "pending",
    })
    .returning()

  await db.insert(orderItems).values(
    resolved.map((r) => ({
      orderId: order.id,
      productId: r.productId,
      productName: r.productName,
      unitType: r.unitType,
      quantity: r.quantity,
      unitPrice: r.unitPrice,
    })),
  )

  // Decrement stock.
  for (const r of resolved) {
    if (r.unitType === "box") {
      await db
        .update(products)
        .set({ boxStock: byId.get(r.productId)!.boxStock - r.quantity })
        .where(and(eq(products.id, r.productId), gt(products.boxStock, 0)))
    } else {
      await db
        .update(products)
        .set({ sachetStock: byId.get(r.productId)!.sachetStock - r.quantity })
        .where(and(eq(products.id, r.productId), gt(products.sachetStock, 0)))
    }
  }

  return { ok: true as const, orderId: order.id }
}
